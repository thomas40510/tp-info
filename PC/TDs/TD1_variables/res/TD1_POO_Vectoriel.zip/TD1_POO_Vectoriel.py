###################
## TD1 IPT2      ##
## Denis Renault ##
###################

## Programmation Orientée Objet sur Calcul Vectoriel ##
#######################################################

## Importation des modules ##
#############################

import math as m

## Définition des classes ##
############################

## Définition de la classe point

class Point :
    '''Définition d'un point en coordonnées cartésiennes 3D.'''
    def __init__(self, px = 0, py = 0, pz = 0):
        '''Constructeur du Point.'''
        self.abscisse = px
        self.ordonnee = py
        self.cote = pz

    def affichage(self) :
        '''Affiche le Point sous forme d'une chaîne de caractères.'''
        print ('(', str(self.abscisse), ',', str(self.ordonnee), ',', \
               str(self.cote), ')')

    def format_tuple(self) :
        '''Retourne le Point sous la forme d'un tuple.'''
        return((self.abscisse, self.ordonnee, self.cote))

    def format_list(self) :
        '''Retourne le Point sous la forme d'une liste.'''
        return([self.abscisse, self.ordonnee, self.cote])

    def bipoint(self, p) :
        '''Retourne le vecteur (Point, p).'''
        return(Vecteur(p.abscisse - self.abscisse, p.ordonnee - self.ordonnee,\
                       p.cote - self.cote))

## Définition de la classe vecteur 

class Vecteur :
    '''Définition d'un vecteur en coordonnées cartésiennes 3D.'''
    def __init__(self, vx = 0, vy = 0, vz = 0):
        '''Constructeur du Vecteur.'''
        self.abscisse = vx
        self.ordonnee = vy
        self.cote = vz

    def affichage(self) :
        '''Affiche le Vecteur sous forme d'une chaîne de caractères.'''
        print ('(', str(self.abscisse), ',', str(self.ordonnee), ',', \
               str(self.cote), ')')

    def format_tuple(self) :
        '''Retourne le Vecteur sous la forme d'un tuple.'''
        return((self.abscisse, self.ordonnee, self.cote))

    def format_list(self) :
        '''Retourne le Vecteur sous la forme d'une liste.'''
        return([self.abscisse, self.ordonnee, self.cote])

    def __add__(self, other) :
        '''Retourne un Vecteur qui est l'addition du Vecteur et du vecteur v.'''
        return(Vecteur(self.abscisse + other.abscisse,\
                       self.ordonnee + other.ordonnee ,\
                       self.cote + other.cote))

    def __mul__(self, k):
        '''Retourne un Vecteur qui est le Vecteur initial multiplié par k.'''
        return(Vecteur(self.abscisse * k, self.ordonnee * k, self.cote * k))
                
    def produit_scalaire(self, v):
        '''Retourne le produit scalaire du Vecteur par v.'''
        return(self.abscisse * v.abscisse + self.ordonnee * v.ordonnee +\
               self.cote * v.cote)
    
    def norme(self) :
        '''Retourne la norme du Vecteur.'''
        return(m.sqrt(self.produit_scalaire(self)))

    def produit_vectoriel(self, v):
        '''Retourne le produit vectoriel du Vecteur par v.'''
        return(Vecteur(self.ordonnee * v.cote - self.cote * v.ordonnee,\
                       self.cote * v.abscisse - self.abscisse * v.cote,\
                       self.abscisse * v.ordonnee - self.ordonnee * v.abscisse))

    def unitaire(self) :
        '''Retourne le vecteur unitaire colinéaire au Vecteur.'''
        if self.norme() == 0 :
            return(Vecteur())
        else :
            return(self.multiplication_scalaire(1 / self.norme()))

    def glisseur(self, point) :
        '''Retourne un Torseur glisseur à partir d'une résultante
et d'un point.'''
        return(Torseur(self, Moment(point, self, Vecteur())))

## Définition de la classe moment 
               
class Moment :
    '''Définition d'un Moment en coordonnées cartésiennes 3D.'''
    def __init__(self, point = Point(), resultante = Vecteur(), \
                 vecteur_moment = Vecteur()):
        '''Constructeur du Torseur.'''
        self.point = point
        self.resultante = resultante
        self.moment = vecteur_moment

    def affichage(self) :
        '''Affiche le Moment sous forme d'une chaîne de caractères.'''
        print ('Au point :')
        self.point.affichage()
        print ('Avec la résultante :')
        self.resultante.affichage()
        print ('Le moment vaut :')
        self.moment.affichage()

## Définition de la classe torseur 

class Torseur :
    '''Définition d'un Torseur en coordonnées cartésiennes 3D.'''
    def __init__(self, resultante = Vecteur(), moment = Moment()):
        '''Constructeur du Torseur.'''
        self.resultante = resultante
        self.moment = moment

    def affichage(self) :
        '''Affiche le vecteur sous forme d'une chaîne de caractères.'''
        print ('Résultante :')
        self.resultante.affichage()
        print ('Moment :')
        self.moment.affichage()

    def varignon(self, point) :
        '''Retourne le résultat de la relation de Varignon du Torseur au
nouveau point.'''
        if self.moment.point.format_tuple() == point.format_tuple() :
            return(self)
        else :
            return(Torseur(self.resultante, \
                           Moment(point, self.resultante,\
                                  self.moment.moment.addition(\
                                      point.bipoint(self.moment.point).\
                                      produit_vectoriel(self.resultante)))))

## Tests ##
###########
        
p_1 = Point()


print(p_1.__doc__)
print(p_1)

O = Point() ; print(O.abscisse)
A = Point(-1, 0, 2); print(A); print(A.cote)
B = Point(0, 3, 7)
v1 = A.bipoint(B)
v2 = Vecteur(-1, 5, 2)
print('v1', end =':') ; v1.affichage()
print('v2', end =':') ; v2.affichage()



