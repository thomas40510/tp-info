# -*- coding: utf-8 -*-

"""
Taux de conversion de l'ammoniac en fonction de la température.
"""

from math import log, pow, exp
import matplotlib.pyplot as plt

# Variables globales utilisées dans l'ensemble du programme

R = 8.314
n1 = 1.0      # quantité initiale de N2 (mole)
n2 = 3.0      # quantité initiale de H2 (mole)
n3 = 0.0      # quantité initiale de NH3 (mole)
Tmin = 400.0  # température minimale de l'étude (kelvin)
Tmax = 800.0  # température maximale de l'étude (kelvin)
deltaT = 10.0 # intervalle de température entre deux calculs (kelvin)

# ========================================================================
# Début de la partie à modifier par le candidat

DrH0 = ? 92000 # enthalpie standard de réaction en J/mol : signe à préciser
DrS0 = ? 200   # entropie standard de réaction en J/K/mol : signe à préciser


def A(ksi, T, P):
    """
    Calcul de l'affinité chimique de la réaction.
    
    Paramètres
        ksi (float): avancement de la réaction
        T (float): température (kelvin)
        P (float): pression globale (bar)
    
    Résultat
       float: affinité chimique de la réaction en J/mol
    """
    # À compléter


def ksi_eq(mini, maxi, precision, T, P):
    """
    Calcul de l'avancement à l'équilibre
    
    Paramètres
        mini (float): avancement minimum à considérer
        maxi (float): avancement maximum à considérer
        precision (float): précision absolue souhaitée pour le résultat
        T (float): température (kelvin)
        P (float): pression globale (bar)
    
    Résultat
        float: valeur approchée de l'avancement à l'équilibre à ±precision près
    """
    # À compléter


def plot_taux(P):
    """
    Calcul d'une série de points de la courbe taux de conversion=f(T).
    
    Paramètre
        P (float): pression globale (bar)
    
    Résultat
        (liste des abscisses, liste des ordonnées) des points calculés
    """
    Temp = [] # abscisses : température
    Taux = [] # ordonnées : taux de conversion
    
    # À compléter
    
    # Exemple d'appel de ksi_eq :
    taux = ksi_eq(0.00001, min(n1, n2/3), 0.001, T, P)
    
    return Temp, Taux


# Fin de la partie à modifier par le candidat
# ========================================================================


# Tracé du taux d'avancement en fonction de la température pour des
# pressions de 1, 2 et 5 bar

for P in (1, 2, 5):
    X, Y = plot_taux(P)
    plt.plot(X, Y)
plt.xlabel("Température (K)")
plt.ylabel("Taux de conversion")
plt.title("Synthèse de l'ammoniac")
plt.show()
