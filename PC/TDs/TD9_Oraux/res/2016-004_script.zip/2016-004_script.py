# Vous avez la liberté complète de modifier l'ensemble du programme
# de façon à répondre aux questions de l'épreuve.
# Le lancement du programme s'effectue au moyen de la touche F5 ou
# du menu 'Exécuter' --> 'Exécuter le fichier'

import scipy as sp
import matplotlib.pyplot as plt

# Données spécifiques au problème
D = 1.4e-7 # Coefficient de diffusion thermique (m^2/s)

# Données spécifiques à la résolution numérique
N = 100 # Nombre de points
R = 2e-2 # Rayon de l'oeuf (m)
le = R/N # Pas d'intégration (distance en m)

n = 10000 # Nombre de points

# Profil initial de température, à modifier
T = (N-1)*[0.0 + 273.15] + [0.0 + 273.15]

tn = 15*60 # Durée de l'expérience (s), à modifier

taue = tn/n # Pas d'intégration (duree en s)

r = sp.linspace(0, R, N) # Valeurs en abscisse

plt.figure(1)
for i in range(n): # Durée de l'expérience representée par 'n' points
    Theta = [0]
    for j in range(N-1):
        Theta.append((T[j+1]-T[j]) / le) # Calcul des derivées premières de T par rapport à 'x'
    for k in range(N-1): # La dernière valeur du profil reste inchangée
        T[k] = T[k] + taue / le * D / ((k+1)*le)**2 * (((k+1)*le)**2 * Theta[k+1] - (k*le)**2 * Theta[k]) # Ajustement des valeurs de T dans le profil de température
    if i*10%n == 0: # Représentation de 10 courbes uniquement
        plt.plot(r, T)

plt.plot(r, T) # Représentation de la dernière courbe
plt.xlabel('$r \ \mathrm{(m)}$')
plt.ylabel('$T \ \mathrm{(K)}$')
plt.title('Representation de $T(r,t=t_n)$')
plt.show()
