## méthodes numériques

def euler(y0, z0, f, tmin, tmax, n):
    '''renvoie les listes des valeurs de y et de z dont les valeurs sont
approchées par la méthode d'Euler explicite.'''
    Y = [y0]
    Z = [z0]
    h = (tmax - tmin) / (n - 1)
    for i in range(1, n):
        Y.append(Y[i - 1] + h * Z[i - 1])
        Z.append(Z[i - 1] + h * f(Y[i - 1]))
    return (Y, Z)

def verlet(y0, z0, f, tmin, tmax, n):
    '''renvoie les listes des valeurs de y et de z dont les valeurs sont
approchées par la méthode de Verlet.'''
    Y = [y0]
    Z = [z0]
    h = (tmax - tmin) / (n - 1)
    for i in range(1, n):
        Y.append(Y[i - 1] + h * Z[i - 1] + (pow(h, 2) / 2) * f(Y[i - 1]))
        Z.append(Z[i - 1] + (h / 2) * (f(Y[i - 1]) + f(Y[i])))
    return (Y, Z)
