## fonctions utilitaires

def smul(k, L):
    '''renvoie la liste composée du produit par k de chaque élément de L.'''
    return [k * elt for elt in L]

def vsom(L1, L2):
    '''renvoie la liste composée de la somme des éléments de chaque liste.'''
    return [a + b for a, b in zip(L1, L2)]

def vdif(L1, L2):
    '''renvoie la liste composée de la différence des éléments
de chaque liste.'''
    return vsom(L1, smul(-1, L2))

