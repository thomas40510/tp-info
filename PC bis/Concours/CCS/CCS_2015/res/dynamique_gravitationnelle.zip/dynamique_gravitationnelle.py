## Problème à N corps

import fonctions_utilitaires as ut

G = 6.67e-11    # Constante de gravitation universelle

def distance(p1, p2):
    '''renvoie la distance en mêtres entre p1 et p2 entrés sous forme
de listes de trois coordonnées cartésiennes en mètres.'''
    return pow(sum([pow(a - b, 2) for a, b in zip(p1, p2)]), 0.5)

def force2(m1, p1, m2, p2):
    '''renvoie la valeur de la force exercée par le corps 2 sur le corps 1,
sous la forme d’une liste à trois éléments représentant les composantes
de la force dans la base de référence, en newtons.'''
    return ut.smul(G * m1 * m2 / pow(distance(p1, p2), 3), ut.vdif(p2, p1))

#### Test des fonctions
##
##rT = 6371e3         # Rayon de la Terre en m
##mT = 5.972e24       # Masse de la Terre en kg
##pT = [0] * 3        # Position de la Terre
##
##pO = [rT, 0, 0]     # Position d'un objet terrestre à la surface
##mO = 1              # Masse de l'objet en kg
##
##print('distance :', distance(pT, pO))
##
##print('accélération de la pesanteur au niveau de la mer :', \
##      force2(mO, pO, mT, pT)[0])
##
##print('accélération de la pesanteur au sommet de l\'Everest :', \
##      force2(mO, ut.vsom(pO, [8848, 0, 0]), mT, pT)[0])

def forceN(j, m, pos):
    '''renvoie la force exercée par tous les autres corps sur le corps j,
sous la forme d'une liste de ses trois composantes cartésiennes.'''
    res = [0] * 3
    for k in range(len(m)):
        if k != j:
            res = ut.vsom(res, force2(m[j], pos[j], m[k], pos[k]))
    return res

#### Suite test des fonctions
##
##rL = 356410e3       # Périgée de la Lune par rapport à la Terre en m
##mL = 7.36e22        # Masse de la Lune en kg
##pL = [rL, 0, 0]
##
##m = [mT, mO, mL]
##pos = [pT, pO, pL]
##
##print('''accélération de la pesanteur au niveau de la mer
##avec la Lune au plus près :''', forceN(1, m, pos)[0])

def pos_suiv(m, pos, vit, h):
    '''renvoie la liste des positions des N corps à l'instant t_{i + 1}
calculées en utilisant le schéma de Verlet.'''
    res = []
    for j in range(len(m)):
        res.append(\
            ut.vsom(pos[j], \
                 ut.vsom(\
                     ut.smul(h, vit[j]), \
                     ut.smul(pow(h, 2) / 2 / m[j], forceN(j, m, pos)))))
    return res

def etat_suiv(m, pos, vit, h):
    '''renvoie la liste des positions (en mètres) et la liste des vitesses
(en m/s) des N corps à l'instant t_{i+1} calculées en utilisant le schéma
de Verlet.'''
    res_pos = pos_suiv(m, pos, vit, h)
    
    res_vit = []
    for j in range(len(m)):
        fj = forceN(j, m, pos)
        res_vit.append(ut.vsom(vit[j], ut.smul(h / 2 / m[j], ut.vsom(\
            fj, forceN(j, m, res_pos)))))
    return res_pos, res_vit
