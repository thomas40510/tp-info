## Problème à N corps

import fonctions_utilitaires as ut

G = 6.67e-11    # Constante de gravitation universelle

def distance(p1, p2):
    '''renvoie la distance en mêtres entre p1 et p2 entrés sous forme
de listes de trois coordonnées cartésiennes en mètres.'''
    return pow(sum([pow(a - b, 2) for a, b in zip(p1, p2)]), 0.5)

def force2(m1, p1, m2, p2):
    '''renvoie la valeur de la force exercée par le corps 2 sur le corps 1,
sous la forme d’une liste à trois éléments représentant les composantes
de la force dans la base de référence, en newtons.'''
    return ut.smul(G * m1 * m2 / pow(distance(p1, p2), 3), ut.vdif(p2, p1))

def forceN(j, m, pos):
    '''renvoie la force exercée par tous les autres corps sur le corps j,
sous la forme d'une liste de ses trois composantes cartésiennes.'''
    res = [0] * 3
    for k in range(len(m)):
        if k != j:
            res = ut.vsom(res, force2(m[j], pos[j], m[k], pos[k]))
    return res

def pos_suiv(m, pos, vit, h):
    '''renvoie la liste des positions des N corps à l'instant t_{i + 1}
calculées en utilisant le schéma de Verlet.'''
    res = []
    for j in range(len(m)):
        res.append(\
            ut.vsom(pos[j], \
                 ut.vsom(\
                     ut.smul(h, vit[j]), \
                     ut.smul(pow(h, 2) / 2 / m[j], forceN(j, m, pos)))))
    return res

def etat_suiv(m, pos, vit, h):
    '''renvoie la liste des positions (en mètres) et la liste des vitesses
(en m/s) des N corps à l'instant t_{i+1} calculées en utilisant le schéma
de Verlet.'''
    res_pos = pos_suiv(m, pos, vit, h)
    
    res_vit = []
    for j in range(len(m)):
        fj = forceN(j, m, pos)
        res_vit.append(ut.vsom(vit[j], ut.smul(h / 2 / m[j], ut.vsom(\
            fj, forceN(j, m, res_pos)))))
    return res_pos, res_vit


def simulation_verlet(p0, v0, masse, delta_t, n):
    '''renvoie la liste des positions des corps considérés pour chaque instant.
Les calculs seront menés en utilisant le schéma d'intégration de Verlet,
le résultat sera fourni en unité astronomique.'''

    # Conversion des positions et vitesses initiales
    ua, km = 1.5e11, 1e3    # constantes de conversion ua -> m et km/s -> m/s
    p0_conv = [ut.smul(ua, pos) for pos in p0]
    v0_conv = [ut.smul(km, vit) for vit in v0]
    
    res_pos = [p0_conv]      # initialisation de la liste à renvoyer, p0 en ua
    vitesses = [v0_conv]     # initialisation de la liste à renvoyer, v0 en km/s

    for instant in range(1, n):
        (pos_i, vit_i) = etat_suiv(masse, res_pos[instant - 1], \
                           vitesses[instant - 1], delta_t)
        res_pos.append(pos_i)
        vitesses.append(vit_i)

    # Conversion des positions avant leur renvoi
    res_pos = [[ut.smul(1 / ua, pos) for pos in positions] \
               for positions in res_pos]

    return res_pos
