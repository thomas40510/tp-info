## Etude comparative des schemas d'Euler et de Verlet

# Importation des modules
from math import pi     # Pour avoir une valeur de pi
import numpy as np
import matplotlib.pyplot as plt # Pour tracer les courbes

# Importation des fonctions precedentes
import fonctions_utilitaires as ut
import schemas_numeriques as snum

# Declaration des constantes
y0, z0 = 3, 0
tmin, tmax, = 0, 3
omega = 2 * pi
n = 100

# Trace des courbes

y0, z0 = 3, 0
omega = 2 * pi
f = lambda x : - pow(omega, 2) * x
periode = 2 * pi / omega
tmax = 3 * periode
tmin = 0
n = 100

def f(x, omega = 2 * pi):
    '''renvoie l'équation différentielle.'''
    return (- pow(omega, 2) * x)

Ye, Ze = snum.euler(y0, z0, f, tmin, tmax, n)

t = np.linspace(tmin, tmax, n)

plt.plot(t, Ye)
plt.xlabel(r'$t$')  # etiquette des abscisses au format LaTeX
plt.ylabel(r'$y$')
plt.title('Euler')
plt.show()

Yv, Zv = snum.verlet(y0, z0, f, tmin, tmax, n)

plt.plot(t, Yv)
plt.xlabel(r'$t$')  # etiquette des abscisses au format LaTeX
plt.ylabel(r'$y$')
plt.title('Verlet')
plt.show()



Ye, Ze = snum.euler(y0, z0, f, tmin, tmax, n)

Yv, Zv = snum.verlet(y0, z0, f, tmin, tmax, n)

plt.figure(1, figsize = (13, 5))

plt.subplot(1, 2, 1)    # 1er sous-graphe parmi 1 ligne et 2 colonnes
plt.plot(Ye, Ze, color = 'grey')
plt.plot(Ye, Ze, linestyle = '*', marker = 'o', markersize = 5,
         markerfacecolor = 'black')
plt.axis([-15, 20, -80, 100])   # precise l'amplitude des axes
plt.title('Euler')
plt.xlabel(r'$y$')
plt.ylabel(r'$z$')

plt.subplot(1, 2, 2)    # 2d sous-graphe
plt.plot(Yv, Zv, color = 'grey')
plt.plot(Yv, Zv, linestyle = '*', marker = 'o', markersize = 5,
         markerfacecolor = 'black')
plt.axis([-10, 10, -80, 100])
plt.title('Verlet')
plt.xlabel(r'$y$')
plt.ylabel(r'$z$')

plt.show()
