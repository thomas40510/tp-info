## Sujet Mines-Ponts 2017
##
## Etude de trafic routier

import os

path = 'D:\\Professionnel\\Informatique\\Enseignement\\Concours\\Mines-Ponts\\2017'

os.chdir(path)

import pixel as px
import numpy as np
import numpy.random as rd

## Préliminaires

def convert(ch_car):
    return([bool(int(elt)) for elt in ch_car])

# version pixel
def px_visualiser(L):
    n = len(L)
    px.initialiser(n, 1, 50)
    for i in range(n):
        px.marquer(i, 1, int(not(L[i])))
    px.afficher(0)


def egal(L1, L2):
    n1, n2 = len(L1), len(L2)
    if n1 != n2:
        return(False)
    else:
        i = 0
        while i < n1 and L1[i] == L2[i]:
            i += 1
        return(i == n1)

## Déplacement de voitures dans la file

# Q8/Q9
def avancer(L, b):
    return([b] + L[: -1])

# version pixel
def px_simul_file(Linit, p = 0.5, N = 100, pause = 0.5):
    '''Simulation d'une file de voitures.
    Linit est la liste initiale.
    L'apparition d'une voiture sur la file suit une loi de Bernoulli de paramètre p, par défaut de 0.5.
    La simulation comporte N étapes, par défaut 100.
    La durée de pause entre chaque étape est de 0.5 seconde par défaut.'''
    n = len(Linit)
    px.initialiser(n, 1, 50)
    for i in range(n):
        px.marquer(i, 0, 0 if Linit[i] else 1)
    px.afficher(5)
    L = Linit[:]
    # Permet de patienter 5 secondes avant de lancer la simulation
    for _ in range(N):
        L = avancer(L, rd.binomial(1, p))
        for i in range(n):
            px.marquer(i, 0, 0 if L[i] else 1)
        px.afficher(pause)
    px.afficher()
    

def avancer_fin(L, m):
    return(L[: m] + avancer(L[m:], False))

def avancer_debut(L, b, m):
    return(avancer(L[: m + 1], b) + L[m + 1 :])

def avancer_debut_bloque(L, b, m):
    # Recherche de la première case libre en amont de m
    i = m - 1
    while i >= 0 and L[i]:
        i -= 1
    if i < 0: 
    # la première case est bouchée, une nouvelle voiture ne peut être insérée
        return(avancer_debut(L, False, i))
    else:
        return(avancer_debut(L, b, i))
    
    
## Une étape de simulation à deux files
        
def avancer_files(L1, b1, L2, b2):
    n1, n2 = len(L1), len(L2)
    m1, m2 = n1 // 2, n2 // 2
    R2 = avancer_fin(L2, m2)
    R1 = avancer(L1, b1)
    if R1[m1]:
        R2 = avancer_debut_bloque(R2, b2, m2)
    else:
        R2 = avancer_debut(R2, b2, m2)
    return([R1, R2])

def versFile(n, taille):
    L = [bool(int(elt)) for elt in list(bin(n))[2:]]
    nL = len(L)
    if nL <= taille:
        return [False] * (taille - nL) + L
    else:
        return L[nL - taille:]

## Simulation complète
def init_files(n1 = 11, n2 = 11, L1 = '', L2 = '', p1 = 0.5, p2 = 0.3):
    '''Initialisation d'un croisement de deux files de longueurs impaires en leurs milieux. La file L1 est prioritaire sur la file L2.
    Les files sont décrites en argument par des nombres binaires.
    Par défaut, les longueurs des piles sont de 11 et elles sont dans une situation aléatoire. 
    L'apparition d'une voiture sur chaque file suit une loi de Bernoulli de paramètre p, par défaut de 0.5 sur la file 1, et de 0.3 sur la file 2.'''
    m1, m2 = n1 // 2, n2 // 2
    if L1 == '':
        L1 = [bool(elt) for elt in rd.binomial(1, p1, n1)]
    elif L1 != '':
        L1 = versFile(int(L1, 2), n1)
    if L2 == '':
        L2 = [bool(elt) for elt in rd.binomial(1, p2, n2)]
        if L1[m1]:
            L2[m2] = False
    elif L2 != '':
        L2 = versFile(int(L2, 2), n2)
    return([L1, L2])

def simul_files(N, E0, p1 = 0.5, p2 = 0.3):
    '''Simulation du croisement de deux files.
    Renvoie une liste de N étapes. Une étape est une liste contenant les états de L1 et de L2.
    E0 est l'étape initiale.
    p1 et p2 les probabilités d'apparition de voitures sur les files correspondantes.'''
    EE = [E0]
    for i in range(N):
        b1, b2 = bool(rd.binomial(1, p1)), bool(rd.binomial(1, p2))
        EE.append(avancer_files(EE[-1][0], b1, EE[-1][1], b2))
    return(EE)
    
  
def px_simul_croisement(N, n1 = 11, n2 = 11, L1 = '', L2 = '', p1 = 0.5, p2 = 0.3, pause = 1):
    '''Simulation de N étapes d'un croisement de deux files de longueurs impaires en leurs milieux. La file L1 est prioritaire sur la file L2.
    Les files sont décrites en argument par des nombres binaires.
    Par défaut, les longueurs des piles sont de 11 et elles sont dans une situation aléatoire. 
    L'apparition d'une voiture sur chaque file suit une loi de Bernoulli de paramètre p, par défaut de 0.5 sur la file 1, et de 0.3 sur la file 2.
    pause est le temps en seconde entre chaque étape.'''
    F0 = init_files(n1, n2, L1, L2, p1, p2)  
    # F est une liste qui contient les files L1 et L2 initiales
    FF = simul_files(N, F0, p1, p2)
    # FF contient la la liste de toutes les étapes de l'évolution du croisement
    
    m1, m2 = n1 // 2, n2 // 2
    
    px.initialiser(n1, n2, 50)
    px.afficher(5)
    
    for k in range(N):
        for largeur in list(range(m1)) + list(range(m1 + 1, n1)):
            px.marquer(largeur, m2, 0 if FF[k][0][largeur] else 1)
        for hauteur in list(range(m2)) + list(range(m2 + 1, n2)):
            px.marquer(m1, hauteur, 0.5 if FF[k][1][hauteur] else 1)
        
        px.marquer(m1, m2, \
        (0 if FF[k][0][m1] else 1) * (0.5 if FF[k][1][m2] else 1))
        px.afficher(pause)
        
    px.afficher()

def animation_croisement(nom, N, n1 = 11, n2 = 11, L1 = '', L2 = '', p1 = 0.5, p2 = 0.3, pause = 1):
    '''nom est une chaîne de caractères pour nommer l'animation.
    Les autres arguments sont les mêmes que px_simul_animation.'''
    F0 = init_files(n1, n2, L1, L2, p1, p2)  
    # F est une liste qui contient les files L1 et L2 initiales
    FF = simul_files(N, F0, p1, p2)
    # FF contient la la liste de toutes les étapes de l'évolution du croisement
    
    m1, m2 = n1 // 2, n2 // 2
    
    # Création du nouveau répertoire pour recueillir toutes les images créées
    os.mkdir('Images_' + nom)
    os.chdir('D:\\Professionnel\\Informatique\\Enseignement\\Concours\\Mines-Ponts\\2017' + '\\Images_' + nom)
    
    px.initialiser(n1, n2, 50)
    # enregistrement de l'image crée par pixel au format png
    px.enregistrer('croisement_' + nom + '_0' + '.png', format_enregistrement = 'png')
    px.afficher(5)
    
    def numero(k, N):
        '''fonction auxiliaire pour afficher une numéro croissant d'images.
        Du type 001 si l'image est à l'indice 1 et qu'il y a entre 100 et 999 images pour l'animation. Sinon l'ordonnancement des images pour créer l'animation gif ne sera pas le bon.'''
        n_chiffres_N = int(np.log10(N)) + 1
        n_chiffres_k = int(np.log10(k)) + 1
        res = '0' * (n_chiffres_N - n_chiffres_k) + str(k)
        return(res)
    
    for k in range(N):
        for largeur in list(range(m1)) + list(range(m1 + 1, n1)):
            px.marquer(largeur, m2, 0 if FF[k][0][largeur] else 1)
        for hauteur in list(range(m2)) + list(range(m2 + 1, n2)):
            px.marquer(m1, hauteur, 0.5 if FF[k][1][hauteur] else 1)
        
        px.marquer(m1, m2, \
        (0 if FF[k][0][m1] else 1) * (0.5 if FF[k][1][m2] else 1))
        # enregistrement de l'image crée par pixel au format png
        px.enregistrer('croisement_' + nom + '_' + numero(k + 1, N) + '.png', format_enregistrement = 'png')
        px.afficher(pause)
        
    px.afficher()
    
    # Elaboration de la commande à exécuter
    cmd = 'magick convert -delay ' + str(pause * 100) + ' -loop 0 croisement_*.png  Anim_croisement_' + nom + '.gif'
    # Exécution de la commande de conversion des images en animation
    os.system(cmd)
    