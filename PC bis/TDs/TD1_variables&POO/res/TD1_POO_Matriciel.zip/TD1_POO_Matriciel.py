###################
## TD1 IPT2      ##
## Denis Renault ##
###################

## Programmation Orientée Objet sur Calcul Matriciel ##
########################################################

## Définition de la classe Matrice

class Matrice :
    '''Définition d'une matrice.'''
    def __init__(self, liste = []):
        '''Constructeur de la matrice.'''
        self.liste = liste # récupération des données
        self.nl = len(liste) # nombre de lignes
        if self.nl > 0 :
            self.nc = len(liste[0]) # nombre de colonnes
            self.dim = (self.nl, self.nc)
        else :
            self.nc = 0
            self.dim = (0, 0)
    
    def affichage(self) :
        '''Affichage de la matrice dans la console.'''
        for ligne in self.liste:
            print('|\t', end = '')
            for col in range(self.nc) :
                print(ligne[col], '\t', end = '')
            print('|')
            
    def colonne(self, j):
        '''Extraction du vecteur colonne j de la matrice, sous forme de matrice colonne.'''
        if j >= self.nc:
            res = []
        else :
            res = [[ligne[j]] for ligne in self.liste]
        return(Matrice(res))
    
    def ligne(self, i):
        '''Extraction du vecteur ligne i de la matrice, sous forme de matrice ligne.'''
        if i >= self.nl:
            res = []
        else :
            res = [self.liste[i]]
        return(Matrice(res))
    
    
    def extraction(self, lmin, lmax, cmin, cmax):
        '''Extraction d'un bloc dans la matrice délimité par les lignes lmin à lmax (compris) et les colonnes cmin et cmax (compris).'''
        if lmin >= self.nl and lmax >= self.nl and cmin >= self.nc and cmax >= self.nc :
            res = []
        else :
            res = [[self.liste[i][j] for j in range(cmin, cmax + 1)] for i in range(lmin, lmax + 1)]
        return(Matrice(res))
    
    def concatenation(self, M):
        '''Concaténation de deux matrices.'''
        assert self.nl == M.nl
        res = [self.liste[i] + M.liste[i] for i in range(self.nl)]
        return(Matrice(res))
    
    def juxtaposition(self, M):
        '''Concaténation de deux matrices.'''
        assert self.nc == M.nc
        res = self.liste + M.liste
        return(Matrice(res))
    
    def __add__(self, other) :
        '''Retourne la matrice qui est l'addition des deux matrices.'''
        assert self.dim == other.dim
        return(Matrice([[self.liste[i][j] + other.liste[i][j] for j in range(self.nc)] for i in range(self.nl)]))
    
    def __mul__(self, value):
        '''Retourne la matrice multipliée par le réel à droite.'''
        return(Matrice([[self.liste[i][j] * value for j in range(self.nc)] for i in range(self.nl)]))
        
    def __and__(self, other):
        '''Retourne la matrice résultat de la multiplication des deux matrices. Ces matrices doivent être compatibles.'''
        assert self.nc == other.nl 
        return(Matrice([[sum([self.liste[i][j] * other.liste[j][k] for j in range(self.nc)]) for k in range(other.nc)] for i in range(self.nl)]))
        
    def transpose(self):
        '''Renvoie la matrice transposée.'''
        return(Matrice([[self.liste[i][j] for i in range(self.nl)] for j in range(self.nc)]))
    
    